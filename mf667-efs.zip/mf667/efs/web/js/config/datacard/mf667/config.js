﻿define(function() {
    var config = {
        HAS_LOGIN:false,
        HAS_WIFI: false,
        HAS_BATTERY: false,
        SHOW_APN_DNS:true,//APN设置页面是否显示DNS，不显示则dnsMode默认设置为auto
        GUEST_HASH: [],
        maxApnNumber: 10,
        WEBUI_TITLE: 'USB-modem "Beeline"',
        AP_STATION_SUPPORT:false,
		SD_CARD_SUPPORT:false,
		HAS_MULTI_SSID: false,
        AUTO_MODES: [ {
            name: 'Automatic',
            value: 'NETWORK_auto'
        }, {
            name: '3G Only',
            value: 'Only_WCDMA'
        }, {
            name: '2G Only',
            value: 'Only_GSM'
        }]
    };

    return config;
});
