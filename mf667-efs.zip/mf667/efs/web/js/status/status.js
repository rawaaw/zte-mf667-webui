define(['jquery'], function($) {
	return {
		init: $.noop
	};
});