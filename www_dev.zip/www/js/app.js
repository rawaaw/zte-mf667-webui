/**
 * @module app
 * @class app
 */
define([
    'config/menu',
    'language',
    'logout',
    'status/statusBar',
    'theme',
    'router',
    'login'],
function(menu, language, logout, statusBar, theme, router, login) {

    /**
     * 初始化系统相关模块
     * @method init
     */
	function init() {
        theme.init();
        menu.init();
        language.init();
        router.init();
        logout.init();
		statusBar.init();
/*
        $("#top_menu_link, #menu_link").unbind('hover').hover(function(){
                $("#menu_link").show();
            },function(){
                $("#menu_link").hide();
            }
        );
		
		$('body').on('mouseenter', '.dropdown', function() {
			$(this).addClass('open');
		}).on('mouseleave', '.dropdown', function() {
			$(this).removeClass('open');
		});*/
	}

	return {
		init: init
	};
});