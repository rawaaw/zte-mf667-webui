﻿define([ 'jquery', 'service', 'knockout', 'config/config', 'status/statusBar'], function ($, service, ko, config, status) {

    function OTAUpdateVM() {
        var self = this;
        var setting = service.getOTAUpdateSetting();
        self.updateMode = ko.observable(setting.updateMode);
        self.originUpdateMode = setting.updateMode;
        self.updateIntervalDay = ko.observable(setting.updateIntervalDay);
        self.originUpdateIntervalDay = setting.updateIntervalDay;
        self.allowRoamingUpdate = ko.observable(setting.allowRoamingUpdate);
        self.originAllowRoaming = setting.allowRoamingUpdate;

        self.clickAllowRoamingUpdate = function () {
            var checkbox = $("#chkUpdateRoamPermission:checked");
            if (checkbox && checkbox.length == 0) {
                self.allowRoamingUpdate("1");
            } else {
                self.allowRoamingUpdate("0");
            }
        };

        self.apply = function () {
            var para = {
                updateMode: self.updateMode(),
                updateIntervalDay: self.updateIntervalDay(),
                allowRoamingUpdate: self.originAllowRoaming
            };
            self.setOTASettings(para);
        }

        self.setRoaming = function () {
            var para = {
                updateMode: self.originUpdateMode,
                updateIntervalDay: self.originUpdateIntervalDay,
                allowRoamingUpdate: self.allowRoamingUpdate()
            };
            self.setOTASettings(para);
        }

        self.setOTASettings = function (para) {
            showLoading('operating');
            service.setOTAUpdateSetting(para, function (data) {
                if (data && data.result == "success") {
                    self.originUpdateMode = para.updateMode;
                    self.originUpdateIntervalDay = para.updateIntervalDay;
                    self.originAllowRoaming = para.allowRoamingUpdate;
                    successOverlay();
                } else {
                    errorOverlay();
                }
            });
        };

        self.checkNewVersion = function () {
            var s = service.getNewVersionState();
            var runningState = ["version_no_new_software", "version_has_new_critical_software"
                , "version_has_new_optional_software", "version_start", "version_processing"
                , "version_roaming", "version_checking", "version_checking_failed"];
            if ($.inArray(s.new_version_state, runningState) != -1) {
                showAlert("ota_update_running");
                return;
            }
            checkNewVersion();
            function checkNewVersion() {
                showLoading("ota_new_version_checking");
                function checkResult() {
                    var r = service.getNewVersionState();
                    if (r.hasNewVersion) {
                        status.showOTAAlert();
                    } else if (r.new_version_state == "0" || r.new_version_state == "version_no_new_software") {
                        showAlert("ota_no_new_version");
                    } else if (r.new_version_state == "version_processing") {
                        showAlert("ota_update_running");
                    } else if (r.new_version_state == "version_roaming") {
                        showAlert("ota_roamming");
                    } else if (r.new_version_state == "version_checking_failed") {
                        errorOverlay("ota_check_fail");
                    } else if (r.new_version_state == "version_idle" || r.new_version_state == "version_start" || r.new_version_state == "version_checking") {
                        addTimeout(checkResult, 1000);
                    }
                }

                service.setUpgradeSelectOp({selectOp: 'check', ota_manual_check_roam_state : ota_manual_check_roam_state}, function (result) {
                    if (result.result == "success") {
                        checkResult();
                    } else {
                        errorOverlay();
                    }
                });
            }
        }

        var  ota_manual_check_roam_state = 0;
        self.checkRoamStatus = function(){
            var roamingStatus = service.getStatusInfo().roamingStatus;
            if(roamingStatus){
                showConfirm("ota_manual_check_roaming_confirm", function () {
                    ota_manual_check_roam_state = 1;
                    self.checkNewVersion();
                });
            }else{
                ota_manual_check_roam_state = 0;
                self.checkNewVersion();
            }

        }

        /**
         * 处理页面元素的可用状态
         * @method fixPageEnable
         */
        self.fixPageEnable = function () {
            var info = service.getConnectionInfo();
            if (checkConnectedStatus(info.connectStatus)) {
                enableBtn($("#btnCheckNewVersion"));
            } else {
                disableBtn($("#btnCheckNewVersion"));
            }
        }
    }

    function init() {
        var container = $('#container')[0];
        ko.cleanNode(container);
        var vm = new OTAUpdateVM();
        ko.applyBindings(vm, container);

        vm.fixPageEnable();
        addInterval(function () {
            vm.fixPageEnable();
        }, 1000);

        $('#frmOTAUpdate').validate({
            submitHandler: function () {
                vm.apply();
            }
        });
    }

    return {
        init: init
    };
});