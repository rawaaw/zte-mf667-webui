({
    appDir: "./",
    baseUrl: "js",
    dir: "../webapp-build",
    //Comment out the optimize line if you want
    //the code minified by UglifyJS
    //optimize: "none",
	mainConfigFile: 'js/main.js',
	
	modules: [
        {
            name: "main",
			exclude: ["jquery", 'config/menu']
        }
    ]
})